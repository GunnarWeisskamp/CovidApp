using APINUnitTest.Models;
using Newtonsoft.Json;
using NUnit.Framework;
using RestSharp;
using RestSharp.Serialization.Json;

namespace APINUnitTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        private const string BASE_URL = "https://localhost:44369/api";

        [Test]
        public void RetrieveDataForUs90210_ShouldYieldBeverlyHills()
        {
            // arrange
            RestClient client = new RestClient(BASE_URL);
            RestRequest request = new RestRequest("PatientDetails/GetPatientDetailsById?id=1", Method.GET);

            //act
            IRestResponse response = client.Execute(request);
            var locationResponse = new JsonDeserializer().Deserialize<string>(response);
            JsonDeserializer a = new JsonDeserializer();
            locationResponse = locationResponse.Replace('\\', ' ');
            PatientDetails account = JsonConvert.DeserializeObject<PatientDetails>(locationResponse);
            //var bb = a.Deserialize Deserialize<PatientDetails>(locationResponse);
            //var bb = JsonSerializer.Deserialize<PatientDetails>(response);

            //var jklj = new JsonDeserializer().Deserialize<string>(locationResponse);

            //assert
            Assert.That(
                locationResponse, Is.EqualTo("Fred")
            );
        }
    }
}