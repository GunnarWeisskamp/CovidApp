﻿using System.Threading.Tasks;
using EntityRepo.ContextInterfaces;
using EntityRepo.CovidAppModels;
using Microsoft.AspNetCore.Mvc;

namespace APICall.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientAddressController : ControllerBase
    {
        private readonly IPatientAddressActions _patAdd;

        public PatientAddressController(IPatientAddressActions patAdd)
        {
            _patAdd = patAdd;
        }

        [HttpGet]
        [Route("GetPatientAddressById")]
        public async Task<PatientAddress> GetPatientAddressById(int id)
        {
            var patAddressById = await _patAdd.GetPatientAddressById(id);

            return patAddressById;
        }
    }
}