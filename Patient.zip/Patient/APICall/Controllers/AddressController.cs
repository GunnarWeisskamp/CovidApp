﻿using System.Collections.Generic;
using APICall.Model;
using Microsoft.AspNetCore.Mvc;

namespace APICall.Controllers
{
    public class AddressController : ControllerBase
    {
        [HttpGet]
        [Route("GetStudentAddress")]
        public StudentAddress GetStudentAddress(int id)
        {

            var studentAddresses = new List<StudentAddress>();
            studentAddresses.Add(
                new StudentAddress() { city = "Brisbane", street = "1 High Street", Id = 1 }
            );

            studentAddresses.Add(
                new StudentAddress() { city = "Sydney", street = "21 Slow Lane", Id = 2 }
            );

            var singleStudentAddress = studentAddresses.Find(x => x.Id == id);
            return singleStudentAddress;
        }
    }
}
