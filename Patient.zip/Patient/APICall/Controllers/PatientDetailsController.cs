﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using APICall.Model;
using EntityRepo.ContextInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace APICall.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientDetailsController : ControllerBase
    {
        private readonly IPatientDetailsActions _patDet;
        private readonly IPatientStoredProcedureActions _patStor;
        public IResultSimpleAPI _resSimpleCls;
        public IPatientDetailsAPI _patDetails;


        public PatientDetailsController(IPatientDetailsActions patDet,
                                        IPatientStoredProcedureActions patStor,
                                        IResultSimpleAPI resSimpleCls,
                                        IPatientDetailsAPI patDetails)
        {
            _patDet = patDet;
            _patStor = patStor;
            _resSimpleCls = resSimpleCls;
            _patDetails = patDetails;
        }

        [HttpGet]
        [Route("GetPatientDetailsById")]
        public async Task<IEnumerable<EntityRepo.CovidAppModels.PatientDetails>> GetPatientDetailsById(int id)
        {
            var patDetailsById = await _patDet.GetPatientDetailsById(id);

            return patDetailsById;
        }

        [HttpGet]
        [Route("GetPatientDetailsByFirstNameAndLastName")]
        public async Task<IEnumerable<EntityRepo.CovidAppModels.PatientDetails>> GetPatientDetailsByFirstNameAndLastName(string firstName, string lastName)
        {
            var patDetailsByFirstAndLastName = await _patDet.GetPatientDetailsByFirstNameAndLastName(firstName, lastName);
            return patDetailsByFirstAndLastName;
        }

        [HttpPost]
        [Route("InsertNewPatientDetailsAndAddress")]
        public async Task<IResultSimpleAPI> sp_InsertNewPatientDetailsAndAddress(InsertNewPatientAPI newPatient)
        {
            try
            {
                string result = await _patStor.sp_InsertNewPatientDetailsAndAddress(newPatient.FirstName, newPatient.LastName,
                                                                                    newPatient.Age, newPatient.Street, newPatient.Suburb,
                                                                                    newPatient.State, newPatient.HospitalName,
                                                                                    newPatient.DateOfTest, newPatient.HealthCarerName,
                                                                                    newPatient.Results, newPatient.Notes);
                if (result.Contains("SQL error has occurred"))
                {
                    // sql error has happened
                    _resSimpleCls.EndMessage = result;
                    _resSimpleCls.IsError = true;
                }
                else
                {
                    _resSimpleCls.EndMessage = result;
                    _resSimpleCls.IsError = false;
                }

            }
            catch (Exception ex)
            {
                _resSimpleCls.EndMessage = "Error has happened please contact customer support with the following error code: " + ex.Message; ;
                _resSimpleCls.IsError = true;
            }

            return _resSimpleCls;
        }

        [HttpPost]
        [Route("updatePatientDetailsAndAddress")]
        public async Task<IResultSimpleAPI> sp_UpdatePatientDetailsAndAddress(UpdatePatientAPI updatePatient)
        {
            try
            {

                string result = await _patStor.sp_UpdatePatientDetailsAndAddress(updatePatient.Id, updatePatient.FirstName, updatePatient.LastName,
                                   updatePatient.Age, updatePatient.Street, updatePatient.Suburb, updatePatient.State);

                if (result.Contains("SQL error has occurred"))
                {
                    // sql error has happened
                    _resSimpleCls.EndMessage = result;
                    _resSimpleCls.IsError = true;
                }
                else
                {
                    _resSimpleCls.EndMessage = result;
                    _resSimpleCls.IsError = false;
                }


            }
            catch (Exception ex)
            {
                _resSimpleCls.EndMessage = "Error has happened please contact customer support with the following error code: " + ex.Message; ;
                _resSimpleCls.IsError = true;
            }

            return _resSimpleCls;
        }

        [HttpGet]
        [Route("GetPatientById")]
        public async Task<IPatientDetailsAPI> GetPatientById(int Id)
        {
            var patDetailsById = await _patDet.GetPatientById(Id); ;
            _patDetails.FirstName = patDetailsById.FirstName;
            _patDetails.LastName = patDetailsById.LastName;
            _patDetails.Age = patDetailsById.Age;
            _patDetails.Street = patDetailsById.PatientAddress.Street;
            _patDetails.Suburb = patDetailsById.PatientAddress.Suburb;
            _patDetails.State = patDetailsById.PatientAddress.State;
            return _patDetails;
        }

    }
}