﻿using System.Collections.Generic;
using APICall.Model;
using Microsoft.AspNetCore.Mvc;

namespace APICall.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        [HttpPost]
        [Route("PostStudent")]
        public string PostStudent(Student std)
        {
            return "hello";
        }

        [HttpGet]
        [Route("GetStudent")]
        public Student GetStudent(string firstName)
        {
            var students = new List<Student>();
            students.Add(
                new Student() { FirstName = "a", LastName = "b", Age = 1, Id = 1 }
            );
            students.Add(
                new Student() { FirstName = "d", LastName = "e", Age = 2, Id = 2 }
            );

            Student singleStudent = new Student();

            singleStudent = students.Find(x => x.FirstName == firstName);

            return singleStudent;
        }

        [HttpGet]
        [Route("GetAllStudents")]
        public IEnumerable<Student> GetAllStudents()
        {
            var students = new List<Student>();
            students.Add(
                new Student() { FirstName = "First", LastName = "Second", Age = 1, Id = 1 }
            );

            students.Add(
                new Student() { FirstName = "Third", LastName = "Fourth", Age = 2, Id = 2 }
            );

            return students;
        }
    }
}
