﻿namespace APICall.Model
{
    public class UpdatePatientAPI
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Suburb { get; set; }
        public string Street { get; set; }
        public string State { get; set; }
    }
}
