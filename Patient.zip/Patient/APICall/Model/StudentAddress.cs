﻿namespace APICall.Model
{
    public class StudentAddress
    {
        public int Id { get; set; }
        public string street { get; set; }

        public string city { get; set; }
    }
}
