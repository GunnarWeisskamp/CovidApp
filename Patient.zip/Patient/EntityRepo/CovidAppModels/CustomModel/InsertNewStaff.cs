﻿namespace EntityRepo.CovidAppModels.CustomModel
{
    public class InsertNewStaff
    {
        public class InsertNewPatient
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int Age { get; set; }
            public string Suburb { get; set; }
            public string Street { get; set; }
            public string State { get; set; }
        }
    }
}
