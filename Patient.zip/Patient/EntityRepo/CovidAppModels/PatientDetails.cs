﻿using System;
using System.Collections.Generic;

namespace EntityRepo.CovidAppModels
{
    public partial class PatientDetails
    {
        public PatientDetails()
        {
            PatientHospital = new HashSet<PatientHospital>();
            PatientHospitalCovidTest = new HashSet<PatientHospitalCovidTest>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? Age { get; set; }

        public PatientAddress PatientAddress { get; set; }
        public ICollection<PatientHospital> PatientHospital { get; set; }
        public ICollection<PatientHospitalCovidTest> PatientHospitalCovidTest { get; set; }
    }
}
