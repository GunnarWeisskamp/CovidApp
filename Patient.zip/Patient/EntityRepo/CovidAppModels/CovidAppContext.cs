﻿using System.Data.Entity.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace EntityRepo.CovidAppModels
{
    public partial class CovidAppContext : DbContext
    {
        public CovidAppContext()
        {
        }

        public CovidAppContext(DbContextOptions<CovidAppContext> options)
            : base(options)
        {
        }
        //Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=CovidApp;Integrated Security=True
        public virtual DbSet<PatientAddress> PatientAddress { get; set; }
        public virtual DbSet<PatientDetails> PatientDetails { get; set; }
        public virtual DbSet<PatientHospital> PatientHospital { get; set; }
        public virtual DbQuery<PatientDetails> Gunnar { get; set; } // your new DbQuery
        public virtual DbSet<PatientHospitalCovidTest> PatientHospitalCovidTest { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CovidApp;Integrated Security=True");
                //Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=CovidApp;Integrated Security = True"
            }
        }

        //public async void GetProductByPriceGreaterThan1000Async()
        //{
        //    // Initialization.  
        //    //List<SpGetProductByPriceGreaterThan1000> lst = new List<SpGetProductByPriceGreaterThan1000>();

        //    try
        //    {
        //        // Processing.  
        //        string sqlQuery = "EXEC [dbo].[GetProductByPriceGreaterThan1000] ";

        //        lst = await PatientDetails.AsSingleQuery<PatientDetails>().FromSql(sqlQuery).ToListAsync();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //    // Info.  
        //    return lst;
        //}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PatientAddress>(entity =>
            {
                entity.HasIndex(e => e.Id)
                    .HasName("IX_PatientAddress");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();

                entity.Property(e => e.PatientDetailsFk).HasColumnName("PatientDetailsFK");

                entity.Property(e => e.State)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Street)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.Suburb)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdNavigation)
                    .WithOne(p => p.PatientAddress)
                    .HasForeignKey<PatientAddress>(d => d.Id)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PatientAddress_PatientDetails1");
            });

            modelBuilder.Entity<PatientDetails>(entity =>
            {
                entity.Property(e => e.FirstName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(300)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PatientHospital>(entity =>
            {
                entity.Property(e => e.DateOfTest).HasColumnType("datetime");

                entity.Property(e => e.HealthCarerName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.HospitalName)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.HasOne(d => d.PatientDetailsIdFkNavigation)
                    .WithMany(p => p.PatientHospital)
                    .HasForeignKey(d => d.PatientDetailsIdFk)
                    .HasConstraintName("FK_PatientHospital_PatientDetails1");
            });

            modelBuilder.Entity<PatientHospitalCovidTest>(entity =>
            {
                entity.Property(e => e.Notes)
                    .HasMaxLength(900)
                    .IsUnicode(false);

                entity.Property(e => e.Result)
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.HasOne(d => d.PatientDetailsIdFkNavigation)
                    .WithMany(p => p.PatientHospitalCovidTest)
                    .HasForeignKey(d => d.PatientDetailsIdFk)
                    .HasConstraintName("FK_PatientHospitalCovidTest_PatientDetails");
            });
        }
    }
}
