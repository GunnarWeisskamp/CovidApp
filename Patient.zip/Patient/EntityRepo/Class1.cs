﻿using System;

namespace EntityRepo
{
	public class Class1
	{
	}
}
