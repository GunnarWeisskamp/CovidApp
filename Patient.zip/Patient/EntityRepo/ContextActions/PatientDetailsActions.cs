﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EntityRepo.ContextInterfaces;
using EntityRepo.CovidAppModels;
using Microsoft.EntityFrameworkCore;

namespace EntityRepo.ContextActions
{
    public class PatientDetailsActions : CovidAppContext, IPatientDetailsActions
    {
        public async Task<IEnumerable<PatientDetails>> GetPatientDetailsById(int id)
        {
            using (var context = new CovidAppContext())
            {
                var patDetails = context.PatientDetails.Where(a => a.Id == id).ToListAsync<PatientDetails>();
                return await patDetails;
            }
        }

        public async Task<IEnumerable<PatientDetails>> GetPatientDetailsByFirstNameAndLastName(string firstName, string lastName)
        {
            using (var context = new CovidAppContext())
            {
                var patDetails = context.PatientDetails.Where(a => a.FirstName == firstName && a.LastName == lastName).ToListAsync<PatientDetails>();
                return await patDetails;
            }
        }

        public async Task<PatientDetails> GetPatientById(int Id)
        {
            using (var context = new CovidAppContext())
            {
                var patDetails = context.PatientDetails.Where(a => a.Id == Id)
                    .Include("PatientAddress")
                    .FirstOrDefaultAsync();
                return await patDetails;
            }
        }
    }
}
