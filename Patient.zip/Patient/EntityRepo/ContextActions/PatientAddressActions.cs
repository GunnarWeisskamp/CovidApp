﻿using System.Linq;
using System.Threading.Tasks;
using EntityRepo.ContextInterfaces;
using EntityRepo.CovidAppModels;
using Microsoft.EntityFrameworkCore;

namespace EntityRepo.ContextActions
{
    public class PatientAddressActions : CovidAppContext, IPatientAddressActions
    {
        public async Task<PatientAddress> GetPatientAddressById(int id)
        {
            using (var context = new CovidAppContext())
            {
                var patAddress = context.PatientAddress.Where(a => a.Id == id).FirstOrDefaultAsync(); ;
                return await patAddress;
            }
        }
    }
}
