﻿using EntityRepo.CovidAppModels;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace EntityRepo.ContextInterfaces
{
	public interface IPatientAddressActions
	{
		Task<PatientAddress> GetPatientAddressById(int id);
	}
}
