﻿using System;
using System.Threading.Tasks;

namespace EntityRepo.ContextInterfaces
{
    public interface IPatientStoredProcedureActions
    {
        Task<string> sp_InsertNewPatientDetailsAndAddress(string FirstName, string LastName, int Age, string Street, string Suburb, string State, string HospitalName, DateTime DateOfTest, string HealthCarerName, Boolean Result, string Notes);

        Task<string> sp_UpdatePatientDetailsAndAddress(int id, string FirstName, string LastName, int Age, string Street, string Suburb, string State);
    }
}
