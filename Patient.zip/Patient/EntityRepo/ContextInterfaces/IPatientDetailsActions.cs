﻿using System.Collections.Generic;
using System.Threading.Tasks;
using EntityRepo.CovidAppModels;

namespace EntityRepo.ContextInterfaces
{
    public interface IPatientDetailsActions
    {
        Task<IEnumerable<PatientDetails>> GetPatientDetailsById(int id);
        Task<IEnumerable<PatientDetails>> GetPatientDetailsByFirstNameAndLastName(string firstName, string lastName);
        Task<PatientDetails> GetPatientById(int Id);

    }
}
