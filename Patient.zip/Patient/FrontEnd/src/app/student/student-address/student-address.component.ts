import { Component, OnInit } from '@angular/core';
//import { ActivatedRoute } from '@angular/router';
import { Router,ActivatedRoute } from '@angular/router';
//import 'rxjs/add/o operator/filter';
//import { filter } from 'rxjs/add/operator/filter'

@Component({
  selector: 'app-student-address',
  templateUrl: './student-address.component.html'
})
export class StudentAddressComponent implements OnInit {
  Id: number;
  constructor(private _Activatedroute:ActivatedRoute,
    private route:Router){}

  ngOnInit(): void {
    this.Id =this._Activatedroute.snapshot.params['id'];  
  }

}
