import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { studentCls } from '../class/student';
import { PostStudentService } from '../services/post-student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  std:studentCls;
  retValue: string;
  constructor(private postData: PostStudentService) { }

  ngOnInit(): void {
    this.std = new studentCls();
  }
  //addHero(hero: Hero): Observable<Hero> {
  postStudentData(stdInput:studentCls ){
    //this.std.age = stdInput.age;
    //this.std.firstName = stdInput.firstName
    //this.std.lastName = stdInput.lastName;
    this.postData.postStudentData(stdInput).
    subscribe(rValue => this.retValue = rValue);;
    ;
  }

}
