import { Component, OnInit } from '@angular/core';
import { GetStudentService } from '../../services/get-student.service';
import { studentCls } from '../../class/student'

@Component({
  selector: 'app-get-student',
  templateUrl: './get-student.component.html',
  styleUrls: ['./get-student.component.css']
})
export class GetStudentComponent implements OnInit {

  firstName: string;
  stdCls: studentCls;
  constructor(private getStd: GetStudentService) { }

  ngOnInit(): void {
    this.stdCls = new studentCls();
  }

  getStudent(){
    this.getStd.getStudent(this.firstName).
    subscribe(value => this.stdCls = value)}
}
