import { Component, OnInit } from '@angular/core';
import { studentCls } from 'src/app/class/student';
import { GetAllStudentsService } from '../../services/get-all-students.service' 

@Component({
  selector: 'app-show-all-std',
  templateUrl: './show-all-std.component.html',
  styleUrls: ['./show-all-std.component.css']
})
export class ShowAllStdComponent implements OnInit {

  stdClsArray: studentCls[] =[];
  stdClsSingle: studentCls;
  constructor(private getAllStd: GetAllStudentsService) { }

  ngOnInit(): void {
    this.getAllStudents();
    //this.stdClsSingle = new studentCls();
    //this.stdClsSingle.firstName = "Fred"; this.stdClsSingle.lastName = "Wallton"; this.stdClsSingle.age = 2;
    //this.stdClsArray.push(this.stdClsSingle);
    //this.stdClsSingle = null;
    //this.stdClsSingle = new studentCls();
    //this.stdClsSingle.firstName = "Tom"; this.stdClsSingle.lastName = "Hello"; this.stdClsSingle.age = 3;
    //this.stdClsArray.push(this.stdClsSingle);
  }

  getAllStudents(){
    this.getAllStd.getAllStudents().
    subscribe(x => this.stdClsArray = x);
  }

}
