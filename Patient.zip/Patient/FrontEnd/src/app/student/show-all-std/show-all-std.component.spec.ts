import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllStdComponent } from './show-all-std.component';

describe('ShowAllStdComponent', () => {
  let component: ShowAllStdComponent;
  let fixture: ComponentFixture<ShowAllStdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowAllStdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowAllStdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
