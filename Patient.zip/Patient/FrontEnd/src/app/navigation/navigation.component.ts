import { Component, DoCheck, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements  OnInit, DoCheck, OnDestroy  {
  title = '';
  hideNav: boolean;
  one:number;
  parentMessage = "";
  currentUserName: BehaviorSubject<string>
  constructor (private authService:AuthService, private router:Router) {}
  ngOnInit() {
    this.one = 1;
      this.hideNav =this.authService.isUserLoggedIn();
   }
   
   ngDoCheck(){
    this.hideNav =this.authService.isUserLoggedIn();
    this.currentUserName = this.authService.getLogedOnUser();
   }
   
  logout() {
    this.authService.logoutUser();
    this.router.navigate(['home']);
    this.hideNav = false;
  }

  ngOnDestroy() {
    this.currentUserName.unsubscribe();
  }

}
