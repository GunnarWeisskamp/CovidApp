import { TestBed } from '@angular/core/testing';

import { GetPatientAddressService } from './get-patient-address.service';

describe('GetPatientAddressService', () => {
  let service: GetPatientAddressService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetPatientAddressService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
