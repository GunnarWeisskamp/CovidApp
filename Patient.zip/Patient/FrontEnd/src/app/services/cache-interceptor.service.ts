import { HttpErrorResponse, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { of } from 'rxjs';
import { Observable } from 'rxjs';
import { retry, tap } from 'rxjs/internal/operators';
import { CacheServiceService } from '../services/cache-service.service';
import { catchError } from 'rxjs/operators';
import { ErrorSnackBarService } from './error-snack-bar.service';
@Injectable({
  providedIn: 'root'
})
export class CacheInterceptorService implements HttpInterceptor {

  constructor(private cacheService: CacheServiceService, private errorSer: ErrorSnackBarService) { }  

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {  

    const httpRequest = req.clone({
      headers: new HttpHeaders({
        'Cache-Control': 'max-age=20',
      })
    });

    if(httpRequest.method !== 'GET') { 
      this.cacheService.invalidateCache();
        return next.handle(httpRequest).pipe(
        retry(1),
        catchError((error: HttpErrorResponse) => {
          let errorMsg = "A error has happened contact admin with following code - Error message: " 
          + error.message + " Error status: " + error.status
          this.errorSer.showError(errorMsg)
          return throwError(error);
        })
      ); 
    }
       
  
    // attempt to retrieve a cached response  
    const cachedResponse: HttpResponse<any> = this.cacheService.get(req.url);  
  
    // check if the cached object has data if so return the data
    if (cachedResponse) {  
      return of(cachedResponse);  
    }      
  
    // no cached data on the cached object, go to the server and place data on cached object  
    return next.handle(httpRequest).pipe
    (
      tap(
          event => 
          { 
            if (event instanceof HttpResponse) 
            { 
              this.cacheService.put(httpRequest.url, event); 
            }
          }
         ),
        catchError
          (
            (
              error: HttpErrorResponse
            ) => 
              {
                let errorMsg = "A error has happened contact admin with following code - Error message: " 
                + error.message + " Error status: " + error.status
                this.errorSer.showError(errorMsg)
                return throwError(error);
              }
          )
        )    
    }  
}
