import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { patientDetails } from '../class/patientDetails';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class SearchForPatientsService {

  constructor(private http: HttpClient) { }

  searchForPatientViaId(Id:number) : Observable<patientDetails[]>
  {
    return this.http.get<patientDetails[]>("https://localhost:44369/api/PatientDetails/GetPatientDetailsById?Id=" + Id);
  }

  GetPatientDetailsByFirstNameAndLastName(firstName:string, lastName: string) : Observable<patientDetails[]>
  {
    return this.http.get<patientDetails[]>("https://localhost:44369/api/PatientDetails/GetPatientDetailsByFirstNameAndLastName?firstName=" + firstName + "&lastName=" + lastName);
  }
}
