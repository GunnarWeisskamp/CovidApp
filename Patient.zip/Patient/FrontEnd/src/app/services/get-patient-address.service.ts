import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { patientAddress } from '../class/patientAddress';

@Injectable({
  providedIn: 'root'
})
export class GetPatientAddressService {

  constructor(private http: HttpClient) { }

  getPatientAddressById(Id:number) : Observable<patientAddress>
  {
    return this.http.get<patientAddress>("https://localhost:44369/api/PatientAddress/GetPatientAddressById?Id=" + Id);
  }
}
