import { Injectable } from '@angular/core';
import { studentCls } from '../class/student';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PostStudentService {

  constructor(private http: HttpClient) { }

  postStudentData(stdData:studentCls){
    let HTTPOptions:Object = {
      headers: new HttpHeaders({
          'Content-Type': 'application/json'
      }),
      responseType: 'text'
    }
    return this.http.post<string>("https://localhost:44369/api/Student",stdData, HTTPOptions)
  }
}
