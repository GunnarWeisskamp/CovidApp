import { TestBed } from '@angular/core/testing';

import { SearchForPatientsService } from './search-for-patients.service';

describe('SearchForPatientsService', () => {
  let service: SearchForPatientsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SearchForPatientsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
