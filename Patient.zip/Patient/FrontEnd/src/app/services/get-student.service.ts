import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { studentCls } from '../class/student';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetStudentService {

  constructor(private http: HttpClient) { }

  getStudent(firstName: string): Observable<studentCls>{
    return this.http.get<studentCls>("https://localhost:44369/api/Student?firstName=" + firstName);
  }
}
