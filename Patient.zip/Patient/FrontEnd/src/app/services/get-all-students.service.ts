import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { studentCls } from '../class/student';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetAllStudentsService {

  constructor(private http: HttpClient) { }

  getAllStudents():Observable<studentCls[]>{
    return this.http.get<studentCls[]>("https://localhost:44369/api/Student/GetAllStudents");
  }
}
