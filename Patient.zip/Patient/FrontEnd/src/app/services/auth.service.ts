import { Injectable, OnDestroy } from '@angular/core';
import { BehaviorSubject, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
    private userName = new BehaviorSubject('default message');
    currentMessage = this.userName.asObservable();
    private isloggedIn: boolean;
 
    constructor() {
        this.isloggedIn=false;
    }
 
    login(username: string, password:string) {
        this.isloggedIn=true;
        this.userName.next(username)
        return of(this.isloggedIn);
    }

    getLogedOnUser():BehaviorSubject<string>{
        return this.userName
    }
 
    isUserLoggedIn(): boolean {
        return this.isloggedIn;
    }
 
    
    logoutUser(): void{
        this.isloggedIn = false;
        //this.userName.unsubscribe();
    }
}
