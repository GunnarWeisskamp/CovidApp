import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { patient } from '../class/patient';
import { Observable } from 'rxjs';
import { resultSimple } from '../class/resultSimple';

@Injectable({
  providedIn: 'root'
})
export class PatientDetailsService {

  constructor(private http: HttpClient) { }

  insertNewPatient(patData:patient): Observable<resultSimple>{
    // let HTTPOptions:Object = {
    //   headers: new HttpHeaders({
    //       'Content-Type': 'application/json'
    //   }),
    //   responseType: 'text'
    // }
    return this.http.post<resultSimple>("https://localhost:44369/api/PatientDetails/InsertNewPatientDetailsAndAddress", patData)
  }

  getPatientById(id:number):Observable<patient>{
    return this.http.get<patient>("https://localhost:44369/api/PatientDetails/GetPatientById?id=" + id);
  }

  updatePatient(currPatient: patient):Observable<resultSimple>{
    return this.http.post<resultSimple>("https://localhost:44369/api/PatientDetails/updatePatientDetailsAndAddress", currPatient)
  }
}
