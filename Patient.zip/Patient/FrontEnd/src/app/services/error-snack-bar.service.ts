import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ErrorSnackBarComponent } from '../../app/errorHandle/error-snack-bar/error-snack-bar.component';

@Injectable({
  providedIn: 'root'
})
export class ErrorSnackBarService {

  constructor(public snackBar: MatSnackBar, public errorSer: ErrorSnackBarComponent) {}

  showSuccess(message: string): void {
    this.errorSer.showSuccess(message)
    //this.snackBar.open(message);
  }
  
  showError(message: string): void {
    // The second parameter is the text in the button. 
    // In the third, we send in the css class for the snack bar.
    //this.snackBar.open(message, 'X', {panelClass: ['error']});
    this.errorSer.showError(message)
  }
}
