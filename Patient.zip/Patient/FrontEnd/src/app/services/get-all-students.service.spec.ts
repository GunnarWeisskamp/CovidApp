import { TestBed } from '@angular/core/testing';

import { GetAllStudentsService } from './get-all-students.service';

describe('GetAllStudentsService', () => {
  let service: GetAllStudentsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GetAllStudentsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
