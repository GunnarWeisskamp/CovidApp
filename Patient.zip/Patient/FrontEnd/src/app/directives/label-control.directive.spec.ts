import { LabelControlDirective } from './label-control.directive';

describe('LabelControlDirective', () => {
  it('should create an instance', () => {
    const directive = new LabelControlDirective();
    expect(directive).toBeTruthy();
  });
});
