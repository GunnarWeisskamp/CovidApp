import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientAddressViewComponent } from './patient-address-view.component';

describe('PatientAddressViewComponent', () => {
  let component: PatientAddressViewComponent;
  let fixture: ComponentFixture<PatientAddressViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientAddressViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientAddressViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
