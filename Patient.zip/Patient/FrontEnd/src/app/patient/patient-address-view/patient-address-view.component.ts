import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GetPatientAddressService } from '../../services/get-patient-address.service';
import { patientAddress } from '../../class/patientAddress';

@Component({
  selector: 'app-patient-address-view',
  templateUrl: './patient-address-view.component.html',
  styleUrls: ['./patient-address-view.component.css']
})
export class PatientAddressViewComponent implements OnInit {

  Id: number;
  patAdd: patientAddress;
  constructor(private _Activatedroute:ActivatedRoute, private patAddSer: GetPatientAddressService){}

  ngOnInit(): void {
    this.Id =this._Activatedroute.snapshot.params['id'];  
    this.patAdd = new patientAddress();
    this.patAddSer.getPatientAddressById(this.Id).
    subscribe(value => this.patAdd = value);
  }


}
