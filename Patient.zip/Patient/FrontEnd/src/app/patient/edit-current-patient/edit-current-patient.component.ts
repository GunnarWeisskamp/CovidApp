import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { patient } from 'src/app/class/patient';
import { resultSimple } from 'src/app/class/resultSimple';
import { PatientDetailsService } from 'src/app/services/patient-details.service';

@Component({
  selector: 'app-edit-current-patient',
  templateUrl: './edit-current-patient.component.html',
  styleUrls: ['./edit-current-patient.component.css']
})
export class EditCurrentPatientComponent implements OnInit {
  patientCls: patient;
  currentState: string;
  selectedValue: number;
  
  state = [
    {id: 0, name: "--Please Select--"},
    {id: 1, name: "QLD"},
    {id: 2, name: "NSW"},
    {id: 3, name: "ACT"},
    {id: 4, name: "VIC"},
    {id: 5, name: "TAS"},
    {id: 6, name: "SA"},
    {id: 7, name: "WA"},
    {id: 8, name: "NT"}
  ];

  public selected = this.state[0];

  public stateCategory =  new FormControl(this.state)
 
  profileForm = new FormGroup({
    id: new FormControl('', [Validators.required]),
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    age: new FormControl('', [Validators.required, Validators.pattern(/^-?(0|[1-9]\d*)?$/)]),
    street: new FormControl('', [Validators.required]),
    suburb: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required]),
    currentStateSelected: new FormControl(''),
    firstNameLoad: new FormControl(''),
    lastNameLoad: new FormControl(''),
    ageLoad: new FormControl(''),
    streetLoad: new FormControl(''),
    suburbLoad: new FormControl(''),
    stateLoad: new FormControl('')
  });
  resultFromInsert: resultSimple;
  pageLoading: number;
  constructor(private patDetailsSer: PatientDetailsService) { }

  ngOnInit(): void {
    this.patientCls = new patient();
    this.pageLoading = 1;
    this.profileForm.controls['id'].setValue('');
    this.profileForm.controls['state'].setValue(0);
  }

  getPatientById(){
    if(this.profileForm.get('id').value === "")
    {
      this.profileForm.controls['id'].setErrors({'required': true});
    }
    else
    {
      this.profileForm.controls['id'].setErrors(null);
    }


    return this.patDetailsSer.getPatientById(parseInt(this.profileForm.get('id').value.toString())).subscribe(value => 
      {
        this.profileForm.controls['firstName'].setValue(value.firstName);
        this.profileForm.controls['lastName'].setValue(value.lastName);
        this.profileForm.controls['age'].setValue(value.age);
        this.profileForm.controls['street'].setValue(value.street);
        this.profileForm.controls['suburb'].setValue(value.suburb);
        this.profileForm.controls['state'].setValue(value.state);
        this.selectedValue = this.getState(value.state);
        this.currentState = value.state;
        this.profileForm.controls['firstNameLoad'].setValue(value.firstName);
        this.profileForm.controls['lastNameLoad'].setValue(value.lastName);
        this.profileForm.controls['ageLoad'].setValue(value.age);
        this.profileForm.controls['suburbLoad'].setValue(value.suburb);
        this.profileForm.controls['streetLoad'].setValue(value.street);
        this.profileForm.controls['stateLoad'].setValue(value.state);

      })
  }
  onSubmit(){ 
    this.patientCls.id = parseInt(this.profileForm.get('id').value.toString());
    this.patientCls.firstName = this.profileForm.get('firstName').value;
    this.patientCls.lastName = this.profileForm.get('lastName').value;
    this.patientCls.age = parseInt(this.profileForm.get('age').value);
    this.patientCls.street = this.profileForm.get('street').value;
    this.patientCls.suburb = this.profileForm.get('suburb').value;
    this.patientCls.state = this.profileForm.get('state').value;
    this.patDetailsSer.updatePatient(this.patientCls)
    .subscribe
      ( retValue => 
        {
          this.resultFromInsert = retValue;
          this.pageLoading = 2;
        }
      );
  }
  getState(stateValue: string):number{
    let id = this.state.find(el => el.name == stateValue).id;
    return id;
  }

  test():boolean{
    if(this.profileForm.get('id').value.toString() === ""){
      return true;
    }
    else
    {
      return false
    }
  }

  onChange(value) 
  {
    if(value === "0")
    {
      this.profileForm.controls['state'].setErrors({'required': true});
    }
    else
    {
      this.profileForm.controls['state'].setErrors(null);
    }
  }
}
   