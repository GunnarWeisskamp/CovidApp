import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditCurrentPatientComponent } from './edit-current-patient.component';

describe('EditCurrentPatientComponent', () => {
  let component: EditCurrentPatientComponent;
  let fixture: ComponentFixture<EditCurrentPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditCurrentPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditCurrentPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
