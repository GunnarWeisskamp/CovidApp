import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertNewPatientComponent } from './insert-new-patient.component';

describe('InsertNewPatientComponent', () => {
  let component: InsertNewPatientComponent;
  let fixture: ComponentFixture<InsertNewPatientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertNewPatientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertNewPatientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
