import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import * as moment from 'moment';
import { patient } from 'src/app/class/patient';
import { resultSimple } from 'src/app/class/resultSimple';
import { PatientDetailsService } from '../../services/patient-details.service';

@Component({
  selector: 'app-insert-new-patient',
  templateUrl: './insert-new-patient.component.html',
  styleUrls: ['./insert-new-patient.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class InsertNewPatientComponent implements OnInit {
  patientCls: patient;
  isReadOnly: boolean;
  stateArray = [
    {id: 0, name: "--Please Select--"},
    {id: 1, name: "QLD"},
    {id: 2, name: "NSW"},
    {id: 3, name: "ACT"},
    {id: 4, name: "VIC"},
    {id: 5, name: "TAS"},
    {id: 6, name: "SA"},
    {id: 7, name: "WA"},
    {id: 8, name: "NT"}
  ];
  selectedValue = 0;
  profileForm = new FormGroup({
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('', [Validators.required]),
    age: new FormControl('', [Validators.required, Validators.pattern(/^-?(0|[1-9]\d*)?$/)]),
    street: new FormControl('', [Validators.required]),
    suburb: new FormControl('', [Validators.required]),
    state: new FormControl('', [Validators.required, Validators.pattern(/^[1-9][0-9]*$/)]),
    hospitalName: new FormControl('', [Validators.required]),
    dateOfTest: new FormControl('', [Validators.required]),
    healthCarerName: new FormControl('', [Validators.required]),
    results: new FormControl('', [Validators.required]),
    notes: new FormControl('', [Validators.required]),
  });
  resultFromInsert: resultSimple;
  pageLoading: number;
  positive: boolean;
  negative: boolean;

  constructor(private patInsertSer: PatientDetailsService ) { }
  
  ngOnInit(): void {
    this.resultFromInsert = new resultSimple();
    this.resultFromInsert.isError = false;
    this.patientCls = new patient();
    this.pageLoading = 1;
    this.profileForm.controls['state'].setValue('');
    this.isReadOnly = false;
  }

  myTest():ValidatorFn{
    return (control: FormControl): {[key: string]:boolean} => {
      if(control.value === 0)
      {
        return {'myTest': false};
      }
      return {'myTest': true};
    };
  }
  checkReadOnly(){
    if(this.profileForm.valid)
    {
      this.isReadOnly = true;
    }
    else
    {
      this.isReadOnly = false;
    }
  }
  onSubmit(){
    this.patientCls.firstName = this.profileForm.get('firstName').value;
    this.patientCls.lastName = this.profileForm.get('lastName').value;
    this.patientCls.age = parseInt(this.profileForm.get('age').value);
    this.patientCls.street = this.profileForm.get('street').value;
    this.patientCls.suburb = this.profileForm.get('suburb').value;
    this.patientCls.state = this.getState(this.profileForm.get('state').value);
    this.patientCls.hospitalName = this.profileForm.get('hospitalName').value;
    
    this.patientCls.dateOfTest = new Date(moment(this.profileForm.get('dateOfTest').value).format("YYYY-MM-DD"));
    
    this.patientCls.healthCarerName = this.profileForm.get('healthCarerName').value;

    this.patientCls.results = (this.profileForm.get('results').value == "0") ? true : false;

    this.patientCls.notes = this.profileForm.get('notes').value;
    this.patInsertSer.insertNewPatient(this.patientCls)
    .subscribe
      ( act => 
        {
          this.resultFromInsert = act;
          this.pageLoading = 2;
        }
      );
  }

  getState(stateValue: number):string{
    return this.stateArray.find(el => el.id == stateValue).name;
  }
  checkResult(event){
    if(event.target.name === "negative")
    {
      this.positive = false;
      this.negative = true
    }
    else
    {
      this.positive = true;
      this.negative = false
    }
  }
}
