import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { patientDetails } from 'src/app/class/patientDetails';
import { SearchForPatientsService } from 'src/app/services/search-for-patients.service';

@Component({
  selector: 'app-patient-details-view',
  templateUrl: './patient-details-view.component.html',
  styleUrls: ['./patient-details-view.component.css']
})
export class PatientDetailsViewComponent implements OnInit {

  isReadOnly: boolean;
  showByID:boolean;
  showByName:boolean;
  searchButton:boolean;
  patDetCls: patientDetails;
  patClsArray: patientDetails[] =[];
  displayedColumns: string[] = ['id', 'firstName', 'lastName', 'age'];
  noResultsRet: number;
  amountOfRecordsRet: number;
  
  patientDetailsForm = new FormGroup({
    id: new FormControl('', [Validators.required]),
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('',[Validators.required]),
    searchPre: new FormControl('',[Validators.required])
  })

  constructor(private _getPatSer: SearchForPatientsService) { }

  ngOnInit(): void {
    this.patientDetailsForm.controls['searchPre'].setValue('byId');
    this.patClsArray[0] = new patientDetails();
    this.patClsArray[0].id = null;
    this.patClsArray[0].firstName = '';
    this.patClsArray[0].lastName = '';
    this.patClsArray[0].age = null;
    this.showByID = true;
    this.showByName = false;
    this.searchButton = false;
    this.noResultsRet = 1;
  }

  showSearchItems(){
    this.searchButton = false; 
    this.patientDetailsForm.controls['firstName'].setValue('');
    this.patientDetailsForm.controls['lastName'].setValue('');
    this.patientDetailsForm.controls['id'].setValue('');
    if(this.patientDetailsForm.get('searchPre').value === "byId")
    {
      this.showByID = true;
      this.showByName = false;
    }
    else
    {
      this.showByID = false;
      this.showByName = true;
    }
  }
  checkInput()
  {
    this.searchButton = false; 
    if(this.patientDetailsForm.get('searchPre').value === "byName")
    { 
      if((this.patientDetailsForm.get('firstName').value !== "" && this.patientDetailsForm.get('lastName').value !== "") || 
        (this.patientDetailsForm.get('firstName').value === null || this.patientDetailsForm.get('lastName').value === null))
      {
        this.searchButton = true;
      }
    }

    if(this.patientDetailsForm.get('searchPre').value === "byId")
    { 
      if(isNaN(this.patientDetailsForm.get('id').value) == false && 
         this.patientDetailsForm.get('id').value !== "")
      {
        this.searchButton = true;
      }
    }
  }

  searchForPatient()
  {
    if(this.patientDetailsForm.get('searchPre').value === "byId")
    { 
      this._getPatSer.searchForPatientViaId(parseInt(this.patientDetailsForm.get('id').value)).
      subscribe(value => this.patClsArray = value)
    }
    else
    {
      this._getPatSer.GetPatientDetailsByFirstNameAndLastName(this.patientDetailsForm.get('firstName').value, this.patientDetailsForm.get('lastName').value).
      subscribe(value => 
        {
          this.patClsArray = value;
          if(this.patClsArray.length == 0)
          {
            //no data present
            this.noResultsRet = 2;
          }
          else
          {
            this.noResultsRet = 3;
            this.amountOfRecordsRet = this.patClsArray.length;
          }
        })
    }
  }

}
