import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-error-snack-bar',
  templateUrl: './error-snack-bar.component.html',
  styleUrls: ['./error-snack-bar.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class ErrorSnackBarComponent implements OnInit {

  isVisilbe:boolean
  constructor(public snackBar: MatSnackBar) { }

  ngOnInit(): void {
  }

  showSuccess(message: string): void {
    this.snackBar.open(message);
  }
  
  showError(message: string): void {
    // The second parameter is the text in the button. 
    // In the third, we send in the css class for the snack bar.
    //alert('hello');
    this.snackBar.open(message, 'X');
  }

}
