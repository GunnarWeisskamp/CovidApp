import { AfterViewInit, OnDestroy } from '@angular/core';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { login } from '../class/login';
import { AuthService } from '../services/auth.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy  {
  invalidCredentialMsg: string;
  retUrl:string="home";
  isReadOnly: boolean;
  private unsubscribeSubObser: Subject<any> = new Subject<any>();

  loginForm = new FormGroup({
    userName: new FormControl('',[Validators.required]),
    password: new FormControl('', [Validators.required])
  });

  constructor(private authService: AuthService, 
              private router: Router, 
              private activatedRoute:ActivatedRoute) {
  }

  ngOnInit() {
      this.activatedRoute.queryParamMap
          .subscribe(params => {
          this.retUrl = params.get('retUrl'); 
          console.log( 'LoginComponent/ngOnInit '+ this.retUrl);
      });
  }

  checkInput()
  {
    this.isReadOnly = false; 
    if((this.loginForm.get('userName').value !== "" && this.loginForm.get('password').value !== "") || 
      (this.loginForm.get('userName').value === null || this.loginForm.get('password').value === null))
    {
      this.isReadOnly = true;
    }
  }

  onFormSubmit(loginForm) {
     this.authService.login(loginForm.value.userName, loginForm.value.password).pipe(
      takeUntil(this.unsubscribeSubObser)
    )
     .subscribe(data => 
      {
                          if (this.retUrl!=null) 
                          {
                                this.router.navigate( [this.retUrl]);
                          } else 
                          {
                                this.router.navigate( ['home']);
                          }
      }).unsubscribe;
  }

  ngOnDestroy() {
    this.unsubscribeSubObser.next();
    this.unsubscribeSubObser.complete();
  }
} 
