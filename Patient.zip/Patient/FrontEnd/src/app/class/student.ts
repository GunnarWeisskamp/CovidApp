export class studentCls {
    id:number;
    firstName:string;
    lastName:string;
    age:number;
}