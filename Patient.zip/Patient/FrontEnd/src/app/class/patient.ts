export class patient{
    id: number;
    firstName: string;
    lastName: string;
    age:number;
    street:string;
    suburb:string;
    state:string;
    hospitalName:string;
    dateOfTest:Date;
    healthCarerName:string;
    results:boolean;
    notes:string;
}