export class patientAddress{
    id:number;
    street:string;
    suburb:string;
    state:string;
}