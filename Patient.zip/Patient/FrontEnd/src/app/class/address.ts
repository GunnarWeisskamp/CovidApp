export class address {
    id:number;
    street:string;
    city:string;
}