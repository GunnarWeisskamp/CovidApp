export class patientDetails{
    id:number;
    firstName:string;
    lastName:string;
    age:number;
}