export class resultSimple {
    endMessage: string;
    isError: boolean;
}