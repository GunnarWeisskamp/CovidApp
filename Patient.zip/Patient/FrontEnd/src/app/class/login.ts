export class login{
    userName: string;
    password: string;
}