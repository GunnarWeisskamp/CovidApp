import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
const animals=['Cat', 'Dog', 'Lion']
@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  
  mainForm: FormGroup;
  options = animals;
  constructor(private fb: FormBuilder) { }
  ngOnInit() {
    this.mainForm = this.fb.group({
      favouriteAnimal: 'Dog'
    })
  }
  removeOptions() {
    this.options = [];
  }
  setCat(){
    this.mainForm.get('favouriteAnimal').setValue('Cat')
  }
  setSelectOptions(){
    this.options = animals;
  }
}
