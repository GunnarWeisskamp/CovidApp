import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { StudentComponent } from './student/student.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { GetStudentComponent } from './student/get-student/get-student.component';
import { ShowAllStdComponent } from './student/show-all-std/show-all-std.component';
import { StudentAddressComponent } from './student/student-address/student-address.component';
import { NavigationComponent } from './navigation/navigation.component';
import { PatientDetailsViewComponent } from './patient/patient-details-view/patient-details-view.component';
import { PatientAddressViewComponent } from './patient/patient-address-view/patient-address-view.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {AngularMaterialModule} from 'src/app/angular-material.module';
import { ProductComponent } from './product/product.component';
import { HomeComponent } from './home/home.component';
import { ContactComponent } from './contact/contact.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { LoginComponent } from '../app/login/login.component';
import { InsertNewPatientComponent } from './patient/insert-new-patient/insert-new-patient.component';
import { EditCurrentPatientComponent } from './patient/edit-current-patient/edit-current-patient.component';
import { LabelControl } from './directives/label-control.directive';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { TestComponent } from './test/test.component';
import { MatNativeDateModule } from '@angular/material/core';
import { CacheInterceptorService } from '../app/services/cache-interceptor.service';
import { ErrorSnackBarComponent } from './errorHandle/error-snack-bar/error-snack-bar.component';
import { MatSnackBar } from '@angular/material/snack-bar';

@NgModule({
  declarations: [
    AppComponent,
    StudentComponent,
    GetStudentComponent,
    ShowAllStdComponent,
    StudentAddressComponent,
    NavigationComponent,
    PatientDetailsViewComponent,
    PatientAddressViewComponent,
    ProductComponent,
    HomeComponent,
    ContactComponent,
    LoginComponent,
    InsertNewPatientComponent,
    EditCurrentPatientComponent,
    LabelControl,
    TestComponent,
    ErrorSnackBarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AngularMaterialModule,
    ReactiveFormsModule,
    MatNativeDateModule
  ],
  providers: [ { provide: HTTP_INTERCEPTORS, useClass: CacheInterceptorService, multi: true }, MatSnackBar, ErrorSnackBarComponent ],
  bootstrap: [AppComponent]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);
