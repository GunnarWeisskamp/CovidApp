import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PatientAddressViewComponent } from './patient/patient-address-view/patient-address-view.component';
import { PatientDetailsViewComponent } from './patient/patient-details-view/patient-details-view.component';
import { ProductComponent } from './product/product.component';
import { AuthGuardService } from './services/auth-guard.service';

import { HomeComponent} from '../app/home/home.component';
import { ContactComponent} from '../app/contact/contact.component';
import { LoginComponent } from '../app/login/login.component';
import { AppComponent } from './app.component';
import { InsertNewPatientComponent } from './patient/insert-new-patient/insert-new-patient.component';
import { EditCurrentPatientComponent } from './patient/edit-current-patient/edit-current-patient.component';


const routes: Routes = [
  //{ path: 'patientAddressComponent/:id', component: PatientAddressViewComponent },
  //{ path: 'patientDetailsViewComponent', component: PatientDetailsViewComponent},
  { path: 'home', component: HomeComponent },
  { path: 'login', component:LoginComponent},
 
  { path: 'patientDetailsViewComponent/:id', component: PatientDetailsViewComponent },
  { path: 'patientInsertComponent', component: InsertNewPatientComponent, canActivate : [AuthGuardService] },
  { path: 'patientEditComponent', component: EditCurrentPatientComponent, canActivate : [AuthGuardService] },
  { path: 'patientAddressComponent/:id', component: PatientAddressViewComponent}, 
  { path: 'contact', component: ContactComponent },
  { path: '', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
