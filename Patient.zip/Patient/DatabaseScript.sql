
CREATE TABLE [dbo].[PatientDetails](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[FirstName] [varchar](300) NULL,
	[LastName] [varchar](300) NULL,
	[Age] [int] NULL,
 CONSTRAINT [PK_PatientDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[PatientAddress](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Street] [varchar](300) NULL,
	[Suburb] [varchar](300) NULL,
	[State] [varchar](40) NULL,
	[PatientDetailsFK] [int] NULL,
 CONSTRAINT [PK_PatientAddress] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PatientAddress]  WITH CHECK ADD  CONSTRAINT [FK_PatientAddress_PatientDetails1] FOREIGN KEY([PatientDetailsFK])
REFERENCES [dbo].[PatientDetails] ([Id])
GO

ALTER TABLE [dbo].[PatientAddress] CHECK CONSTRAINT [FK_PatientAddress_PatientDetails1]
GO

GO

CREATE TABLE [dbo].[PatientHospital](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[HospitalName] [varchar](400) NULL,
	[DateOfTest] [datetime] NULL,
	[HealthCarerName] [varchar](400) NULL,
	[PatientDetailsIdFk] [int] NULL,
 CONSTRAINT [PK_PatientHospital] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PatientHospital]  WITH CHECK ADD  CONSTRAINT [FK_PatientHospital_PatientDetails1] FOREIGN KEY([PatientDetailsIdFk])
REFERENCES [dbo].[PatientDetails] ([Id])
GO

ALTER TABLE [dbo].[PatientHospital] CHECK CONSTRAINT [FK_PatientHospital_PatientDetails1]
GO

GO

CREATE TABLE [dbo].[PatientHospitalCovidTest](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Results] [bit] NULL,
	[Notes] [varchar](100) NULL,
	[PatientHospitalIdFk] [int] NULL,
	[PatientDetailsIdFk] [int] NULL,
 CONSTRAINT [PK_PatientHospitalCovidTest] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[PatientHospitalCovidTest]  WITH CHECK ADD  CONSTRAINT [FK_PatientHospitalCovidTest_PatientDetails1] FOREIGN KEY([PatientDetailsIdFk])
REFERENCES [dbo].[PatientDetails] ([Id])
GO

ALTER TABLE [dbo].[PatientHospitalCovidTest] CHECK CONSTRAINT [FK_PatientHospitalCovidTest_PatientDetails1]
GO

ALTER TABLE [dbo].[PatientHospitalCovidTest]  WITH CHECK ADD  CONSTRAINT [FK_PatientHospitalCovidTest_PatientHospital1] FOREIGN KEY([PatientHospitalIdFk])
REFERENCES [dbo].[PatientHospital] ([Id])
GO

ALTER TABLE [dbo].[PatientHospitalCovidTest] CHECK CONSTRAINT [FK_PatientHospitalCovidTest_PatientHospital1]
GO



GO

CREATE procedure [dbo].[sp_InsertNewPatientDetailsAndAddress]
  @firstName varchar(300) = null,
  @lastName varchar(300) = null,
  @age int = null,
  @street varchar(300) = null,
  @suburb varchar(300) = null,
  @state varchar(40) = null,
  @hospitalName varchar(300) = null,
  @dateOfTest datetime,
  @healthCarerName varchar(300) = null,
  @results bit,
  @notes varchar(300) = null
As
	Set NoCount On
	Declare @patientId int, @patientHospitalIdFk int
	begin try
		Insert dbo.PatientDetails(FirstName, LastName, Age) 
		Values(@firstName, @lastName, @age)
		Set @patientId = scope_Identity()

		Insert dbo.PatientAddress(Street, Suburb, State, PatientDetailsFK)
		values(@street, @suburb, @state, @patientId)

		Insert dbo.PatientHospital(HospitalName, DateOfTest, HealthCarerName, PatientDetailsIdFk)
		Values(@hospitalName, @dateOfTest, @healthCarerName, @patientId)
		set @patientHospitalIdFk = SCOPE_IDENTITY()
		print @patientHospitalIdFk 
		print @patientId

		Insert dbo.PatientHospitalCovidTest(Results, Notes, PatientHospitalIdFk, PatientDetailsIdFk)
		Values(@results, @notes, @patientHospitalIdFk, @patientId)

		select 'New ID of patient: ' + CAST(@patientId as varchar(10)) 
	end try
	begin catch
		SELECT dbo.sqlErrorHandler()
	end catch

GO

CREATE procedure [dbo].[sp_UpdatePatientDetailsAndAddress]
  @id int,
  @firstName varchar(300) = null,
  @lastName varchar(300) = null,
  @age int = null,
  @street varchar(300) = null,
  @suburb varchar(300) = null,
  @state varchar(40) = null
As
	Set NoCount On
	declare @test int;
	begin try
		set @test = cast('a' as varchar(10))
		update dbo.PatientDetails set FirstName = @firstName, LastName = @lastName, Age = @age where id = @id 
		update dbo.PatientAddress set Street = @street, Suburb = @suburb, State = @state where id = @id
		select 'Updated patient Id: ' + CAST(@id as varchar(10)) 
	end try
	begin catch
		SELECT dbo.sqlErrorHandler()
	end catch

GO
ALTER FUNCTION [dbo].[sqlErrorHandler]()
RETURNS varchar(max)
AS 
BEGIN
	declare @errorNumber int, @errorState int, @errorSeverity int, 
	@errorProcedure varchar(max), @errorLine int, @errorMessage varchar(max), @overallErrorMsg varchar(max)

	SELECT  @errorNumber = ERROR_NUMBER(), 
			@errorState = ERROR_STATE(), 
			@errorSeverity = ERROR_SEVERITY(), 
			@errorProcedure = ERROR_PROCEDURE(), 
			@errorLine = ERROR_LINE(), 
			@errorMessage = ERROR_MESSAGE()

	set @overallErrorMsg = 'SQL error has occurred, this is information about the error: ' + 
	'Error Number: ' + 	CAST(isnull(@errorNumber,0) as varchar(10)) + 
	' Error State:  ' + CAST(isnull(@errorState,0) as varchar(10)) + 
    ' Error Severity: ' + CAST(isnull(@errorSeverity,0) as varchar(10)) + 
	' Error Procedure: ' + isnull(@errorProcedure,'') + 
	' Error Line: ' +  CAST(isnull(@errorLine,0) as varchar(10))  + 
	' Error Message: ' + isnull(@errorMessage,'')
    RETURN @overallErrorMsg
END;
